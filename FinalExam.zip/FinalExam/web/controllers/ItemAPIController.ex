defmodule Fin.ItemAPIController do
  use Fin.Web, :controller
  alias Fin.{Item,Repo,Bid}

 def index(conn,_param)do

  items = Repo.all(from t in Item, select: t)

  items = items  |> Enum.map(fn item -> %{
    name: item.name, 
    id: item.identify, 
    code: item.code, 
    startdate: item.startdate, 
    duedate: item.duedate, 
    times_extended: item.times_extended
   } end)

   items = items |> Enum.sort_by(fn %{id: id} -> id end)

    conn
    |> put_status(200)
    |> json(%{items: items})
  end


  def getitem(conn,p)do
  item = Repo.get(Item,1)

  item =  %{
    name: item.name, 
    id: item.identify, 
    code: item.code, 
    startdate: item.startdate, 
    duedate: item.duedate, 
    times_extended: item.times_extended
        }

    conn
    |> put_status(200)
    |> json(%{item: item})
  end


   def extend(conn, %{"id" => id})do
     item = Repo.get_by(Item,identify: id)
     IO.inspect item
     number_extension = item.times_extended

     if number_extension < 4 do

      due_date = item.duedate
      number_ext = item.times_extended
      book_code = item.code
      myDate = due_date |> Date.from_iso8601!
      case book_code do
        "A" -> myDate = myDate |> Date.add(7)
        "B" -> myDate = myDate |> Date.add(14)
        "C" -> myDate = myDate |> Date.add(21)
      end
      
      new_due = myDate |> Date.to_iso8601()
      number_ext = number_ext + 1

      Repo.update(Item.changeset(item,%{duedate: new_due, times_extended: number_ext}))

      items = Repo.all(from t in Item, select: t)

      items = items  |> Enum.map(fn item -> %{
        name: item.name, 
        id: item.identify, 
        code: item.code, 
        startdate: item.startdate, 
        duedate: item.duedate, 
        times_extended: item.times_extended
      } end)

      items = items |> Enum.sort_by(fn %{id: id} -> id end)

      conn
      |> put_status(200)
      |> json(%{msg: "ACCEPTED", items: items})
      else

      items = Repo.all(from t in Item, select: t)

      items = items  |> Enum.map(fn item -> %{
        name: item.name, 
        id: item.identify, 
        code: item.code, 
        startdate: item.startdate, 
        duedate: item.duedate, 
        times_extended: item.times_extended
      } end)

      items = items |> Enum.sort_by(fn %{id: id} -> id end)
      
      conn
      |> put_status(200)
      |> json(%{msg: "REJECTED", items: items})
      end
  end
end
