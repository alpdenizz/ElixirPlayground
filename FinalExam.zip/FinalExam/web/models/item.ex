defmodule Fin.Item do
  use Fin.Web, :model

  schema "books" do
      field :name, :string
      field :identify, :integer
      field :code, :string
      field :startdate, :string
      field :duedate, :string
      field :times_extended, :integer

    timestamps()
  end

  @doc """
  Builds a changeset based on the `struct` and `params`.
  """
  def changeset(struct, params \\ %{}) do
    struct
    |> cast(params, [:name, :identify, :code, :startdate, :duedate, :times_extended])
    |> validate_required([:name, :identify, :code, :startdate, :duedate, :times_extended])
  end
end
