import Vue from "vue";
import VueRouter from "vue-router";

import main from "./main";
import items from "./items";

import "axios";

Vue.use(VueRouter);
Vue.component("items", items);

var router = new VueRouter({
    routes: [
        { path: '/', component: main} 
    ]
});

new Vue({router}).$mount("#fin");
