<template>
<div>
  <items></items>
</div>
</template>

<script>

export default {
    methods: {
    }
    ,mounted() {
      //do something after mounting vue instance
    }
}
</script>
