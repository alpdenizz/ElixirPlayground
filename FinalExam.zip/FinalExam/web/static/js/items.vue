<template>
  <div>
  <input type="checkbox" name="ongoing" v-on:click="filter()">Show only ongoing loans<br>
  <table class="table">
      <thead>
        <tr>
          <th>Title</th>
          <th>Code</th>
          <th>Start date</th>
          <th>Due date</th>
          <th>Times extended</th>
        </tr>
      </thead>
      <tbody id="candidates">
          <tr v-for="(item,index) in items">

              <td>{{ item.name }}</td>
              <td>{{ item.code}}</td>
              <td>{{ item.startdate }}</td>
              <td>{{ item.duedate }}</td>
              <td>{{ item.times_extended }}</td>
              <td><button class="btn btn-primary" :id="index + 1" v-on:click="extendBook(index+1)">Extend</button></td>
          </tr>
      </tbody>
</table>
<div v-html="messages" class="col-sm-12" style="background-color:#f4f7ff;height:40pt"></div>
</div>

</template>


<script>
import axios from "axios";

export default {

  data: function(){

    return {
      items: [],
      full_items: [],
      messages: ""
    }
  },
  methods: {
    extendBook: function (id) {
      axios.post("/api/items/extend", {id: id}).then(response => {
                      console.log(response)
                      this.messages = response.data.msg
                      this.items = response.data.items
                      }).catch(error => {
                          console.log(error);
                      });
     },
     filter: function () {
       this.items = [];
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1; //January is 0!
        var yyyy = today.getFullYear();

      if(dd<10) {
          dd = '0'+dd
      } 

      if(mm<10) {
          mm = '0'+mm
      } 

        today = yyyy + '-' + mm + '-' + dd;
        for(var i=0; i<this.full_items.length; i++) {
          date = this.full_items[i].duedate
          if(date >= today) items.push(this.full_items[i])
        }
        
     }
  },
  mounted: function() {
    axios.get("/api/items").then(response => {
                      this.items = response.data.items
                      this.full_items = response.data.items
                              console.log(this.items)
                      }).catch(error => {
                          console.log(error);
                      });
  },
  
}
</script>
