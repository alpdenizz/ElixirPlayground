defmodule Fin.PageView do
  use Fin.Web, :view
end
