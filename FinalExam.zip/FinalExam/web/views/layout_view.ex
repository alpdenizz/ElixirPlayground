defmodule Fin.LayoutView do
  use Fin.Web, :view
end
