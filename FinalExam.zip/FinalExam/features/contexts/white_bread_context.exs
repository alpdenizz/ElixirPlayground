defmodule WhiteBreadContext do
  use WhiteBread.Context
      use Hound.Helpers
  alias Fin.{Item,Repo}
  import Ecto.Query
  feature_starting_state fn  ->
    Application.ensure_all_started(:hound)
    %{}
  end
  scenario_starting_state fn state ->
    Hound.start_session
    Ecto.Adapters.SQL.Sandbox.checkout(Fin.Repo)
    Ecto.Adapters.SQL.Sandbox.mode(Fin.Repo, {:shared, self()})
    %{}
  end
  scenario_finalize fn _status, _state ->
    Ecto.Adapters.SQL.Sandbox.checkin(Fin.Repo)
    Hound.end_session
  end

  given_ ~r/^the book loans in library system$/, fn state, %{table_data: table} ->

        table
        |> Enum.map(fn item -> Item.changeset(%Item{}, item) end)
        |> Enum.each(fn changeset -> Repo.insert!(changeset) end)
        {:ok, state}

    end

and_ ~r/^I want extend "(?<book>[^"]+)"$/,
fn state, %{book: book} ->
  {:ok, state |> Map.put(:book_extended, book)}
end


and_ ~r/^I open my book loans$/, fn state ->
  navigate_to "/#"
  {:ok, state}
end

when_ ~r/^I submit extend request$/, fn state ->
  book_name = state[:book_extended]
  query = from t in Item, where: t.name == ^book_name, select: t
  book = Repo.all(query) |> hd
  %{identify: identify} = book
  value = to_string(identify)
  click({:id, value})
  {:ok, state}
end

then_ ~r/^I should receive acception of my request$/, fn state ->
  Process.sleep 2000
  assert visible_in_page? ~r/#{"ACCEPTED"}/
  {:ok, state}
end

then_ ~r/^I should receive rejection of my request$/, fn state ->
  assert visible_in_page? ~r/#{"REJECTED"}/
  {:ok, state}
end

end
