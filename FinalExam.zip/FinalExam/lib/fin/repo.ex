defmodule Fin.Repo do
  use Ecto.Repo, otp_app: :fin
end
