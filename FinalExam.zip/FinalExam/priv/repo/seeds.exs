# Script for populating the database. You can run it as:
#
#     mix run priv/repo/seeds.exs
#
# Inside the script, you can read and write to any of your
# repositories directly:
#
#     Fin.Repo.insert!(%Fin.SomeModel{})
#
# We recommend using the bang functions (`insert!`, `update!`
# and so on) as they will halt execution if something goes wrong.
alias Fin.{Repo,Item}
[
  %{name: "Programming Phoenix 1.3", identify: 1, code: "A", startdate: "2018-01-09", duedate: "2018-01-16", times_extended: 0},
  %{name: "Secrets of the JavaScript ninja", identify: 2, code: "A", startdate: "2017-12-19", duedate: "2018-01-16", times_extended: 4}
 ]
 |> Enum.each(fn item -> Repo.insert!(Item.changeset(%Item{}, 
  %{name: item.name, identify: item.identify, code: item.code, startdate: item.startdate, duedate: item.duedate, times_extended: item.times_extended })) end)
