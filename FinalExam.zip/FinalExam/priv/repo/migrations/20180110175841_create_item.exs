defmodule Fin.Repo.Migrations.CreateItem do
  use Ecto.Migration

  def change do
    create table(:books) do
      add :name, :string
      add :identify, :integer
      add :code, :string
      add :startdate, :string
      add :duedate, :string
      add :times_extended, :integer

      timestamps()
    end
  end
end
