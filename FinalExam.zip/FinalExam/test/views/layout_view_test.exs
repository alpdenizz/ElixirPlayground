defmodule Fin.LayoutViewTest do
  use Fin.ConnCase, async: true
end
