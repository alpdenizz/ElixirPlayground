defmodule Fin.PageViewTest do
  use Fin.ConnCase, async: true
end
