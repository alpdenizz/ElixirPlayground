defmodule Fin.ItemTest do
  use Fin.ModelCase

  alias Fin.Item

  @valid_attrs %{closingdate: "some closingdate", description: "some description", price: "some price"}
  @invalid_attrs %{}

  test "changeset with valid attributes" do
    changeset = Item.changeset(%Item{}, @valid_attrs)
    assert changeset.valid?
  end

  test "changeset with invalid attributes" do
    changeset = Item.changeset(%Item{}, @invalid_attrs)
    refute changeset.valid?
  end
end
