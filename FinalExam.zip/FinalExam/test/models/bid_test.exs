defmodule Fin.BidTest do
  use Fin.ModelCase

  alias Fin.Bid

  @valid_attrs %{offered_price: "some offered_price"}
  @invalid_attrs %{}

  test "changeset with valid attributes" do
    changeset = Bid.changeset(%Bid{}, @valid_attrs)
    assert changeset.valid?
  end

  test "changeset with invalid attributes" do
    changeset = Bid.changeset(%Bid{}, @invalid_attrs)
    refute changeset.valid?
  end
end
