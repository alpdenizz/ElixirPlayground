defmodule Fin.ItemControllerTest do
    use Fin.ConnCase
    alias Fin.{Item, Repo}
    
      test "POST /items/extend acceptance", %{conn: conn} do
        [
            %{name: "Programming Phoenix 1.3", identify: 5, code: "A", startdate: "2018-01-09", duedate: "2018-01-16", times_extended: 0},
            %{name: "Secrets of the JavaScript ninja", identify: 6, code: "A", startdate: "2017-12-19", duedate: "2018-01-16", times_extended: 4}
         ]
         |> Enum.map(fn item -> Item.changeset(%Item{}, item) end)
         |> Enum.each(fn item -> Repo.insert!(item) end)      
  
        conn = post conn, "/api/items/extend", %{"id" => 5}
        %{"msg" => message} = Poison.decode! conn.resp_body
        assert message == "ACCEPTED"
        assert conn.status == 200
      end
      
      test "POST /items rejection", %{conn: conn} do
        [
            %{name: "Programming Phoenix 1.3", identify: 7, code: "A", startdate: "2018-01-09", duedate: "2018-01-16", times_extended: 0},
            %{name: "Secrets of the JavaScript ninja", identify: 8, code: "A", startdate: "2017-12-19", duedate: "2018-01-16", times_extended: 4}
         ]
         |> Enum.map(fn item -> Item.changeset(%Item{}, item) end)
         |> Enum.each(fn item -> Repo.insert!(item) end)        
        conn = post conn, "/api/items/extend", %{"id" => 8}
        %{"msg" => message} = Poison.decode! conn.resp_body
        assert message == "REJECTED"
        assert conn.status == 200
    
    end

    test "POST /items acceptance update due date", %{conn: conn} do
        [
            %{name: "Programming Phoenix 1.3", identify: 10, code: "A", startdate: "2018-01-09", duedate: "2018-01-16", times_extended: 0},
         ]
         |> Enum.map(fn item -> Item.changeset(%Item{}, item) end)
         |> Enum.each(fn item -> Repo.insert!(item) end)        
        item = Repo.get_by(Item, identify: 10)
        current_due = item.duedate
        
        conn = post conn, "/api/items/extend", %{"id" => 10}
        %{"msg" => message} = Poison.decode! conn.resp_body
        item = Repo.get_by(Item, identify: 10)
        actual_due = item.duedate
        expected_due = current_due |> Date.from_iso8601! |> Date.add(7) |> Date.to_iso8601
    
        assert message == "ACCEPTED"
        assert conn.status == 200
        assert actual_due == expected_due
    
    end

    test "POST /items reject update due date", %{conn: conn} do
        [
            %{name: "Programming Phoenix 1.3", identify: 11, code: "A", startdate: "2018-01-09", duedate: "2018-01-16", times_extended: 4},
         ]
         |> Enum.map(fn item -> Item.changeset(%Item{}, item) end)
         |> Enum.each(fn item -> Repo.insert!(item) end)        
        item = Repo.get_by(Item, identify: 11)
        current_due = item.duedate
        
        conn = post conn, "/api/items/extend", %{"id" => 11}
        %{"msg" => message} = Poison.decode! conn.resp_body
        item =  Repo.get_by(Item, identify: 11)
        actual_due = item.duedate
        expected_due = current_due
    
        assert message == "REJECTED"
        assert conn.status == 200
        assert actual_due == expected_due
    
    end
    

end