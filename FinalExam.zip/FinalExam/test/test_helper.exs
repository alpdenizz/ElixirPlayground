ExUnit.start

Ecto.Adapters.SQL.Sandbox.mode(Fin.Repo, :manual)

