defmodule Takso.UserView do
  use Takso.Web, :view
end
