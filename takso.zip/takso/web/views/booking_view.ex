defmodule Takso.BookingView do
  use Takso.Web, :view
end
