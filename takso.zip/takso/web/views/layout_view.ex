defmodule Takso.LayoutView do
  use Takso.Web, :view
end
