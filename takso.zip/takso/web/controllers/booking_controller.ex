defmodule Takso.BookingController do
  use Takso.Web, :controller
  import Ecto.Query
  alias Ecto.{Changeset,Multi}

  alias Takso.{Taxi,Booking,Repo,Geolocator}

  def new(conn, params) do
    render conn, "new.html", changeset: Booking.changeset(%Booking{})
  end

  def create(conn, params) do
    %{"booking" => addresses} = params
    %{"dropoff_address" => dropoff, "pickup_address" => pickup} = addresses
    query = from t in Taxi, select: t.location
    locations = Repo.all(query)
    locations = Enum.map(locations, fn(x) -> String.replace(x," ","+") end)
    locations = for loc <- locations, do: loc<>"|"
    str = List.foldr(locations,"",fn(x,acc) -> x<>acc end)
    input = str |> String.split_at(String.length(str)-1) |> elem(0)
    response = Takso.Geolocator.trip_duration(input, pickup)
    estimation = Takso.Geolocator.trip_duration(pickup,dropoff)

    conn
    |> put_flash(:info, "Your taxi will arrive in "<>response<>" and the estimated trip duration will be of "<>estimation)
    |> redirect(to: booking_path(conn, :new))
  end
end
