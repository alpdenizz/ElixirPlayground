defmodule Takso.LayoutViewTest do
  use Takso.ConnCase, async: true
end
