defmodule Takso.Repo do
  use Ecto.Repo, otp_app: :takso
end
