defmodule Takso.PageViewTest do
  use Takso.ConnCase, async: true
end
