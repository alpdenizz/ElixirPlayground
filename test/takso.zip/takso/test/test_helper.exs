ExUnit.start

Ecto.Adapters.SQL.Sandbox.mode(Takso.Repo, :manual)

