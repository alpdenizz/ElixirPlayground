defmodule Takso.HTTPoisonMock do
    def get!(url) do
      inputLine = String.split_at(url,56) |> elem(1)
      list = String.codepoints(inputLine)
      indexAmp = Enum.find_index(list, fn(x) -> x=="&" end)
      tuple = String.split_at(inputLine,indexAmp)
      origin = elem(tuple,0) 
      destination = elem(tuple,1)
      if String.match?(origin, ~r/\|/) do
      destination = String.split_at(destination, (String.length(destination)-14)) |> elem(0) |> String.split_at(14) |> elem(1) |> String.replace("+","_")
        %HTTPoison.Response{
            body: File.read!("test/fixtures/#{destination}.json")
          }
       else
        destination = String.split_at(destination, (String.length(destination)-14)) |> elem(0) |> String.split_at(14) |> elem(1) |> String.replace("+","_")
        origin = String.split_at(origin, (String.length(origin)-14)) |> elem(0) |> String.split_at(8) |> elem(1) |> String.replace("+","_")
        %HTTPoison.Response{
            body: File.read!("test/fixtures/#{origin}__#{destination}.json")
          }
      end
    end
  end