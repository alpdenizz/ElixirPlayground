defmodule Takso.PageView do
  use Takso.Web, :view
end
