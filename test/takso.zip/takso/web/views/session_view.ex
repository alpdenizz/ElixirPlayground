defmodule Takso.SessionView do
  use Takso.Web, :view
end
